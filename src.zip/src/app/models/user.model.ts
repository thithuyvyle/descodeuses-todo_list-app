export interface User { 
    id: number;
    username: number | null;
    lastName:string | null;
    firstName: string | null;
    genre: string | null;
}