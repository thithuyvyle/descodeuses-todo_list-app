export interface Contact {
    id: number | null;
    name: string | null;
}
