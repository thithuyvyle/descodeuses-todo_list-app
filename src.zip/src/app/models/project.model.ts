export interface Project {
    id: number | null;
    title: string | null;
}